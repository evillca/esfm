CREATE TABLE ilcs(
	id_ilc int(11) NOT null AUTO_INCREMENT,
    nombre_ilc varchar(100) NOT NULL,
    id_idioma int(11) NOT NULL,
    CONSTRAINT pk_ilc PRIMARY KEY(id_ilc),
    CONSTRAINT fk_ilc FOREIGN KEY(id_idioma) REFERENCES idiomas(id_idioma)
)ENGINE=INNODB;


INSERT INTO ilcs VALUES (NULL,'TOMAS KATARI XXX',1);
INSERT INTO ilcs VALUES (NULL,'PONCHOS ROJOS',2);



INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'AFROBOLIVIANO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'ARAONA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'AYMARA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'ZAMUCO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'BAURE');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'CANICHANA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'CAYUBABA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'CHACOBO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'BESƗRO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'ESE EJJA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'GUARANI');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'GWARAYU');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'ITONAMA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'JOAQUINIANO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'KAVINEÑO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'MACHAJUYAI-KALLAWAYA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'LECO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'MACHINERI');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'MAROPA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'MOJEÑO IGNACIANO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'MOJEÑO TRINITARIO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'MORE');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'MOSETEN');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'MOVIMA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'PACAHUARA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'QUECHUA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'SIRIONO');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'TACANA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'TAPIETE');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'TSIMANE');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'URU-CHIPAYA');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'WEENHAYEK');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'YUKI');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'YURAKARE');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'GUARASU WE');
INSERT INTO idiomas (id_idioma,nombre_idioma) VALUES (NULL,'YAMINAWA');