<?php
include 'conexion.php';
$nrodocumento = $_GET['nrodocumento'];
$date = date_default_timezone_get();
$cantidad = mysqli_query($conexion, "SELECT * FROM postulantes p, idiomas i WHERE (p.idioma=i.id_idioma) and nrodocumento='".$nrodocumento."'");

$ejecucion_cantidad = mysqli_fetch_array($cantidad);
$nombre1 = $ejecucion_cantidad['nombre1'];
$nombre2 = $ejecucion_cantidad['nombre2'];
$appaterno = $ejecucion_cantidad['appaterno'];
$apmaterno = $ejecucion_cantidad['apmaterno'];
$oral = $ejecucion_cantidad['oral'];
$escrito = $ejecucion_cantidad['escrito'];
$idioma = $ejecucion_cantidad['nombre_idioma'];
$id_idioma = $ejecucion_cantidad['id_idioma'];
$nombre_ilc = $ejecucion_cantidad['ilc'];

$codigo = $ejecucion_cantidad['cod_certificado'];



if($oral==1){
	$oral= "BÁSICO";
}elseif ($oral==2) {
	$oral= "INTERMEDIO";
}elseif($oral==3){
	$oral= "AVANZADO";
}else{
	$oral="APRENDIZAJE ";
}

if($escrito==1){
	$escrito= "BÁSICO";
}elseif ($escrito==2) {
	$escrito= "INTERMEDIO";
}elseif($escrito==3){
	$escrito= "AVANZADO";
}else{
	$escrito="APRENDIZAJE ";
}






/*
if ($ejecucion_cantidad['estado_evaluacion']!=1) {
	header("Location: aspirantes.php");
}*/

use setasign\Fpdi\Fpdi;
require 'libs/vendor/autoload.php';
$pdf = new Fpdi();
$pdf->AddPage();
$pdf->setSourceFile('certificado.pdf');
$tplIdx=$pdf->importPage(1);
$pdf->useTemplate($tplIdx,null,null,null,null,true);

$nombrecompleto=strtoupper($nombre1.' '.$nombre2.' '.$appaterno.' '.$apmaterno);
$dota='evillca';
$fecha=$date;

//codigo certificado
$pdf->SetFont('Arial','B',18);
$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(242, 35);
$pdf->Write(0, utf8_decode($codigo));

//evento
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(220, 35);
$pdf->Write(0, utf8_decode('COD-CERT:'));

//nombre
$pdf->SetFont('Arial','B',18);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(90,86);
$pdf->Write(0, utf8_decode($nombrecompleto));


//ILC
$pdf->SetFont('Arial','B',20);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(90,125);
$pdf->Write(0, utf8_decode($nombre_ilc),);




//nivel oral
$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(60, 106);
$pdf->Write(0, utf8_decode($oral));

//nivel escrito
$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(135, 106);

$pdf->Write(0, utf8_decode($escrito));

//idioma
$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(200, 106);
$pdf->Write(0, utf8_decode($idioma));

//fecha
$pdf->SetFont('Arial','B',8);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(20, 190);
$pdf->Write(0, utf8_decode('Fecha de Impresion:'));
//fecha
$pdf->SetFont('Arial','',8);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(48, 190);
$pdf->Write(0, utf8_decode('18-12-2020'));

//evento
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(225, 30);
$pdf->Write(0, utf8_decode('EVENTO:'));
//codigo evento
$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(242, 30);
$pdf->Write(0, utf8_decode('COVID-19'));



$pdf->Output($nrodocumento.'-'.strtoupper($idioma).'.pdf','I');
$pdf->Output();